#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
    name='scrapy_sqlalchemyitem',
    version='0.1',
    packages=['scrapy_sqlalchemyitem'],
)
